<?php

namespace App\Filament\Resources\ProductWeights\Pages;

use App\Filament\Resources\ProductWeights\ProductWeightResource;
use Filament\Resources\Pages\CreateRecord;

class CreateProductWeight extends CreateRecord
{
    protected static string $resource = ProductWeightResource::class;
}
